/*
 * %W% %E%
 *
 * Copyright 2002 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

#ifndef DXVERSION_H
#define DXVERSION_H

#define DIRECTINPUT_VERSION 0x0800

#endif
